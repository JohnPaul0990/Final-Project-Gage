// scripts.js

let cart = [];

function addToCart(id, name, price) {
    const existingItem = cart.find(item => item.id === id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ id, name, price, quantity: 1 });
    }
    updateCart();
}

function deleteFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
        const li = document.createElement('li');
        li.innerHTML = `${item.name} - $${item.price} x ${item.quantity} 
                        <button onclick="deleteFromCart(${item.id})">Delete</button>`;
        cartItems.appendChild(li);
    });

    document.getElementById('cart-total').innerText = `Total: $${total}`;
}
