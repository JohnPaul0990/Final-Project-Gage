const product = [
    {
        id: 'Corsair Carbide Series SPEC-DELTA RGB.html',
        image:'css/pccase/1.jpg',
        title:'Corsair Carbide Series SPEC-DELTA RGB',
        price: 5756
    },
    {
        id:'Cooler Master MasterBox Q300L.html',
        image:'css/pccase/2.jpg',
        title:'Cooler Master MasterBox Q300L',
        price: 2878
    },
    {
        id:'Deepcool MATREXX 30.html',
        image:'css/pccase/3.jpg',
        title:'Deepcool MATREXX 30',
        price: 2302
    },
    {
        id:'NZXT H710.html',
        image:'css/pccase/4.jpg',
        title:'NZXT H710',
        price: 8634
    },
    {
        id:'Fractal Design Meshify S2.html',
        image:'css/pccase/5.jpg',
        title:'Fractal Design Meshify S2',
        price: 8634
    },
    {
        id:'Corsair Obsidian 500D RGB SE.html',
        image:'css/pccase/6.jpg',
        title:'Corsair Obsidian 500D RGB SE',
        price: 11513
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

