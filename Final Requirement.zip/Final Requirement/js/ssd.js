const product = [
    {
        id: 'Crucial BX500.html',
        image:'css/ssd/1.jpg',
        title:'Crucial BX500',
        price: 4605
    },
    {
        id:'ADATA SU635.html',
        image:'css/ssd/2.jpg',
        title:'ADATA SU635',
        price: 4029
    },
    {
        id:'TeamGroup GX1.html',
        image:'css/ssd/3.jpg',
        title:'TeamGroup GX1',
        price: 2878
    },
    {
        id:'Samsung 970 EVO Plus.html',
        image:'css/ssd/4.jpg',
        title:'Samsung 970 EVO Plus',
        price: 23026
    },
    {
        id:'Western Digital WD Black SN850.html',
        image:'css/ssd/5.jpg',
        title:'Western Digital WD Black SN850',
        price: 28783
    },
    {
        id:'Seagate FireCuda 520.html',
        image:'css/ssd/6.jpg',
        title:'Seagate FireCuda 520',
        price: 28783
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

