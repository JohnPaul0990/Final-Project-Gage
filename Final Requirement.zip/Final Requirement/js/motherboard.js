const product = [
    {
        id: 'ASUS Prime B450M-ACSM.html',
        image:'css/motherboards/1.jpg',
        title:'ASUS Prime B450M-A/CSM',
        price: 4605
    },
    {
        id:'GIGABYTE B365M DS3H.html',
        image:'css/motherboards/2.jpg',
        title:'GIGABYTE B365M DS3H',
        price: 5180
    },
    {
        id:'MSI ProSeries Intel B365 LGA 1151 Support 9th8th Gen Intel Processor.html',
        image:'css/motherboards/3.jpg',
        title:'MSI ProSeries Intel B365 LGA 1151 Support 9th/8th Gen Intel Processor',
        price: 5756
    },
    {
        id:'ASUS ROG Strix X570-E Gaming.html',
        image:'css/motherboards/4.jpg',
        title:'ASUS ROG Strix X570-E Gaming',
        price: 124990
    },
    {
        id:'MSI MEG Z590 ACE.html',
        image:'css/motherboards/5.jpg',
        title:'MSI MEG Z590 ACE',
        price: 25904
    },
    {
        id:'GIGABYTE Z590 AORUS XTREME.html',
        image:'css/motherboards/6.jpg',
        title:'GIGABYTE Z590 AORUS XTREME',
        price: 40296
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);
