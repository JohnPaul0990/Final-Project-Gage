const product = [
    {
        id: '1 NVIDIA GeForce GTX 1050 Ti.html',
        image:'css/gpu/1.jpg',
        title:'NVIDIA GeForce GTX 1050 Ti',
        price: 9210
    },
    {
        id:'2 NVIDIA GeForce GTX 1650 Super.html',
        image:'css/gpu/2.jpg',
        title:'NVIDIA GeForce GTX 1650 Super',
        price: 10361
    },
    {
        id:'3 AMD Radeon RX 570.html',
        image:'css/gpu/3.jpg',
        title:'AMD Radeon RX 570',
        price: 8634
    },
    {
        id:'4 NVIDIA GeForce RTX 3080.html',
        image:'css/gpu/4.jpg',
        title:'NVIDIA GeForce RTX 3080',
        price: 46053
    },
    {
        id:'5 AMD Radeon RX 6900 XT.html',
        image:'css/gpu/5.jpg',
        title:'AMD Radeon RX 6900 XT',
        price: 69079
    },
    {
        id:'6 NVIDIA GeForce RTX 3090.html',
        image:'css/gpu/6.jpg',
        title:'NVIDIA GeForce RTX 3090',
        price: 115133
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);


