const product = [
    {
        id: 'MacBook Air M3.html',
        image:'css/Laptop/1.png',
        title:'MacBook Air M3',
        price: 76990
    },
    {
        id:'Acer Swift Go 14.html',
        image:'css/Laptop/2.png',
        title:'Acer Swift Go 14',
        price: 61999
    },
    {
        id:'LG Gram SuperSlim (2023).html',
        image:'css/Laptop/3.png',
        title:'LG Gram SuperSlim (2023)',
        price: 52350
    },
    {
        id:'Dell XPS 15 (9350).html',
        image:'css/Laptop/4.png',
        title:'Dell XPS 15 (9350)',
        price: 124990
    },
    {
        id:'Asus ROG Strix Scar 18.html',
        image:'css/Laptop/5.png',
        title:'Asus ROG Strix Scar 18',
        price: 147900
    },
    {
        id:'HP Spectre x360 14 2024.html',
        image:'css/Laptop/6.png',
        title:'HP Spectre x360 14 2024',
        price: 116125
    },
    {
        id: '1 AMD Ryzen 3 3100.html',
        image:'css/processor/1.jpg',
        title:'AMD Ryzen 3 3100',
        price: 8634
    },
    {
        id:'2 Intel Core i3-10100.html',
        image:'css/processor/2.jpg',
        title:'Intel Core i3-10100',
        price: 8634
    },
    {
        id:'3 AMD Ryzen 5 2600.html',
        image:'css/processor/3.jpg',
        title:'AMD Ryzen 5 2600',
        price: 11513
    },
    {
        id:'4 AMD Ryzen 9 5950X.html',
        image:'css/processor/4.jpg',
        title:'AMD Ryzen 9 5950X',
        price: 40296
    },
    {
        id:'5 Intel Core i9-11900K.html',
        image:'css/processor/5.jpg',
        title:'Intel Core i9-11900K',
        price: 28783
    },
    {
        id:'6 AMD Ryzen Threadripper 3990X.html',
        image:'css/processor/6.jpg',
        title:'AMD Ryzen Threadripper 3990X',
        price: 172699
    },
    {
        id: 'ASUS Prime B450M-ACSM.html',
        image:'css/motherboards/1.jpg',
        title:'ASUS Prime B450M-A/CSM',
        price: 4605
    },
    {
        id:'GIGABYTE B365M DS3H.html',
        image:'css/motherboards/2.jpg',
        title:'GIGABYTE B365M DS3H',
        price: 5180
    },
    {
        id:'MSI ProSeries Intel B365 LGA 1151 Support 9th8th Gen Intel Processor.html',
        image:'css/motherboards/3.jpg',
        title:'MSI ProSeries Intel B365 LGA 1151 Support 9th/8th Gen Intel Processor',
        price: 5756
    },
    {
        id:'ASUS ROG Strix X570-E Gaming.html',
        image:'css/motherboards/4.jpg',
        title:'ASUS ROG Strix X570-E Gaming',
        price: 124990
    },
    {
        id:'MSI MEG Z590 ACE.html',
        image:'css/motherboards/5.jpg',
        title:'MSI MEG Z590 ACE',
        price: 25904
    },
    {
        id:'GIGABYTE Z590 AORUS XTREME.html',
        image:'css/motherboards/6.jpg',
        title:'GIGABYTE Z590 AORUS XTREME',
        price: 40296
    },
    {
        id: 'ADATA XPG GAMMIX D10 32GB (2 x 16GB) DDR4-3200.html',
        image:'css/memory/3.jpg',
        title:'ADATA XPG GAMMIX D10 32GB (2 x 16GB) DDR4-3200',
        price: 6907
    },
    {
        id:'Corsair Dominator Platinum RGB 128GB (4 x 32GB) DDR4-3200.html',
        image:'css/memory/6.jpg',
        title:'Corsair Dominator Platinum RGB 128GB (4 x 32GB) DDR4-3200',
        price: 46053
    },
    {
        id:'Corsair Vengeance RGB Pro 32GB (2 x 16GB) DDR4-3600.html',
        image:'css/memory/4.jpg',
        title:'Corsair Vengeance RGB Pro 32GB (2 x 16GB) DDR4-3600',
        price: 11513
    },
    {
        id:'Crucial Ballistix Sport LT 8GB DDR4-2400.html',
        image:'css/memory/1.jpg',
        title:'Crucial Ballistix Sport LT 8GB DDR4-2400',
        price: 2302
    },
    {
        id:'G.SKILL Trident Z Neo Series 64GB (4 x 16GB) DDR4-3600.html',
        image:'css/memory/5.jpg',
        title:'G.SKILL Trident Z Neo Series 64GB (4 x 16GB) DDR4-3600',
        price: 23026
    },
    {
        id:'Team T-FORCE VULCAN Z 16GB (2 x 8GB) DDR4-3000.html',
        image:'css/memory/2.jpg',
        title:'Team T-FORCE VULCAN Z 16GB (2 x 8GB) DDR4-3000',
        price: 4029
    },
    {
        id: 'Crucial BX500.html',
        image:'css/ssd/1.jpg',
        title:'Crucial BX500',
        price: 4605
    },
    {
        id:'ADATA SU635.html',
        image:'css/ssd/2.jpg',
        title:'ADATA SU635',
        price: 4029
    },
    {
        id:'TeamGroup GX1.html',
        image:'css/ssd/3.jpg',
        title:'TeamGroup GX1',
        price: 2878
    },
    {
        id:'Samsung 970 EVO Plus.html',
        image:'css/ssd/4.jpg',
        title:'Samsung 970 EVO Plus',
        price: 23026
    },
    {
        id:'Western Digital WD Black SN850.html',
        image:'css/ssd/5.jpg',
        title:'Western Digital WD Black SN850',
        price: 28783
    },
    {
        id:'Seagate FireCuda 520.html',
        image:'css/ssd/6.jpg',
        title:'Seagate FireCuda 520',
        price: 28783
    },
    {
        id: 'EVGA 500 W1, 80+ WHITE 500W.html',
        image:'css/powersupply/1.jpg',
        title:'EVGA 500 W1, 80+ WHITE 500W',
        price: 2878
    },
    {
        id:'Corsair CX Series CX450, 80 PLUS Bronze 450W.html',
        image:'css/powersupply/2.jpg',
        title:'Corsair CX Series CX450, 80 PLUS Bronze 450W',
        price: 3453
    },
    {
        id:'Thermaltake Smart 500W 80+ White Certified PSU.html',
        image:'css/powersupply/3.jpg',
        title:'Thermaltake Smart 500W 80+ White Certified PSU',
        price: 2878
    },
    {
        id:'Seasonic Prime TX-1000, 80+ Titanium 1000W.html',
        image:'css/powersupply/4.jpg',
        title:'Seasonic Prime TX-1000, 80+ Titanium 1000W',
        price: 23026
    },
    {
        id:'Corsair AX1600i, 80+ Titanium 1600W.html',
        image:'css/powersupply/5.jpg',
        title:'Corsair AX1600i, 80+ Titanium 1600W',
        price: 34539
    },
    {
        id:'EVGA SuperNOVA 1300 G2, 80+ Gold 1300W.html',
        image:'css/powersupply/6.jpg',
        title:'EVGA SuperNOVA 1300 G2, 80+ Gold 1300W',
        price: 17269
    },
    {
        id: 'Corsair Carbide Series SPEC-DELTA RGB.html',
        image:'css/pccase/1.jpg',
        title:'Corsair Carbide Series SPEC-DELTA RGB',
        price: 5756
    },
    {
        id:'Cooler Master MasterBox Q300L.html',
        image:'css/pccase/2.jpg',
        title:'Cooler Master MasterBox Q300L',
        price: 2878
    },
    {
        id:'Deepcool MATREXX 30.html',
        image:'css/pccase/3.jpg',
        title:'Deepcool MATREXX 30',
        price: 2302
    },
    {
        id:'NZXT H710.html',
        image:'css/pccase/4.jpg',
        title:'NZXT H710',
        price: 8634
    },
    {
        id:'Fractal Design Meshify S2.html',
        image:'css/pccase/5.jpg',
        title:'Fractal Design Meshify S2',
        price: 8634
    },
    {
        id:'Corsair Obsidian 500D RGB SE.html',
        image:'css/pccase/6.jpg',
        title:'Corsair Obsidian 500D RGB SE',
        price: 11513
    },
    {
        id: '1 NVIDIA GeForce GTX 1050 Ti.html',
        image:'css/gpu/1.jpg',
        title:'NVIDIA GeForce GTX 1050 Ti',
        price: 9210
    },
    {
        id:'2 NVIDIA GeForce GTX 1650 Super.html',
        image:'css/gpu/2.jpg',
        title:'NVIDIA GeForce GTX 1650 Super',
        price: 10361
    },
    {
        id:'3 AMD Radeon RX 570.html',
        image:'css/gpu/3.jpg',
        title:'AMD Radeon RX 570',
        price: 8634
    },
    {
        id:'4 NVIDIA GeForce RTX 3080.html',
        image:'css/gpu/4.jpg',
        title:'NVIDIA GeForce RTX 3080',
        price: 46053
    },
    {
        id:'5 AMD Radeon RX 6900 XT.html',
        image:'css/gpu/5.jpg',
        title:'AMD Radeon RX 6900 XT',
        price: 69079
    },
    {
        id:'6 NVIDIA GeForce RTX 3090.html',
        image:'css/gpu/6.jpg',
        title:'NVIDIA GeForce RTX 3090',
        price: 115133
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

