const product = [
    {
        id: '1 AMD Ryzen 3 3100.html',
        image:'css/processor/1.jpg',
        title:'AMD Ryzen 3 3100',
        price: 8634
    },
    {
        id:'2 Intel Core i3-10100.html',
        image:'css/processor/2.jpg',
        title:'Intel Core i3-10100',
        price: 8634
    },
    {
        id:'3 AMD Ryzen 5 2600.html',
        image:'css/processor/3.jpg',
        title:'AMD Ryzen 5 2600',
        price: 11513
    },
    {
        id:'4 AMD Ryzen 9 5950X.html',
        image:'css/processor/4.jpg',
        title:'AMD Ryzen 9 5950X',
        price: 40296
    },
    {
        id:'5 Intel Core i9-11900K.html',
        image:'css/processor/5.jpg',
        title:'Intel Core i9-11900K',
        price: 28783
    },
    {
        id:'6 AMD Ryzen Threadripper 3990X.html',
        image:'css/processor/6.jpg',
        title:'AMD Ryzen Threadripper 3990X',
        price: 172699
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

