const product = [
    {
        id: 'EVGA 500 W1, 80+ WHITE 500W.html',
        image:'css/powersupply/1.jpg',
        title:'EVGA 500 W1, 80+ WHITE 500W',
        price: 2878
    },
    {
        id:'Corsair CX Series CX450, 80 PLUS Bronze 450W.html',
        image:'css/powersupply/2.jpg',
        title:'Corsair CX Series CX450, 80 PLUS Bronze 450W',
        price: 3453
    },
    {
        id:'Thermaltake Smart 500W 80+ White Certified PSU.html',
        image:'css/powersupply/3.jpg',
        title:'Thermaltake Smart 500W 80+ White Certified PSU',
        price: 2878
    },
    {
        id:'Seasonic Prime TX-1000, 80+ Titanium 1000W.html',
        image:'css/powersupply/4.jpg',
        title:'Seasonic Prime TX-1000, 80+ Titanium 1000W',
        price: 23026
    },
    {
        id:'Corsair AX1600i, 80+ Titanium 1600W.html',
        image:'css/powersupply/5.jpg',
        title:'Corsair AX1600i, 80+ Titanium 1600W',
        price: 34539
    },
    {
        id:'EVGA SuperNOVA 1300 G2, 80+ Gold 1300W.html',
        image:'css/powersupply/6.jpg',
        title:'EVGA SuperNOVA 1300 G2, 80+ Gold 1300W',
        price: 17269
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

