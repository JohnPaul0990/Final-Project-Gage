const product = [
    {
        id: 'ADATA XPG GAMMIX D10 32GB (2 x 16GB) DDR4-3200.html',
        image:'css/memory/3.jpg',
        title:'ADATA XPG GAMMIX D10 32GB (2 x 16GB) DDR4-3200',
        price: 6907
    },
    {
        id:'Corsair Dominator Platinum RGB 128GB (4 x 32GB) DDR4-3200.html',
        image:'css/memory/6.jpg',
        title:'Corsair Dominator Platinum RGB 128GB (4 x 32GB) DDR4-3200',
        price: 46053
    },
    {
        id:'Corsair Vengeance RGB Pro 32GB (2 x 16GB) DDR4-3600.html',
        image:'css/memory/4.jpg',
        title:'Corsair Vengeance RGB Pro 32GB (2 x 16GB) DDR4-3600',
        price: 11513
    },
    {
        id:'Crucial Ballistix Sport LT 8GB DDR4-2400.html',
        image:'css/memory/1.jpg',
        title:'Crucial Ballistix Sport LT 8GB DDR4-2400',
        price: 2302
    },
    {
        id:'G.SKILL Trident Z Neo Series 64GB (4 x 16GB) DDR4-3600.html',
        image:'css/memory/5.jpg',
        title:'G.SKILL Trident Z Neo Series 64GB (4 x 16GB) DDR4-3600',
        price: 23026
    },
    {
        id:'Team T-FORCE VULCAN Z 16GB (2 x 8GB) DDR4-3000.html',
        image:'css/memory/2.jpg',
        title:'Team T-FORCE VULCAN Z 16GB (2 x 8GB) DDR4-3000',
        price: 4029
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

