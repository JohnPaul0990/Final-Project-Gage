const product = [
    {
        id: 'AMD Ryzen 9 5950X(high).html',
        image:'css/pccase/3.jpg',
        title:'AMD Ryzen 9 5950X',
        price: 105000
    },
    {
        id:'INTEL CORE I5 13600K(high).html',
        image:'css/pccase/4.jpg',
        title:'INTEL CORE I5 13600K',
        price: 87350
    }
    ];

    const categories = [...new Set(product.map((item) => { return item }))]

    document.getElementById('searchBar').addEventListener('keyup', (e) => {
        const searchData = e.target.value.toLowerCase();
        const filteredData = categories.filter((item) => {
            return (
                item.title.toLowerCase().includes(searchData)
            )
        })
        displayItem(filteredData)
    });

    const displayItem = (items) => {
        document.getElementById('root').innerHTML = items.map((item) => {
            var { id, image, title, price } = item;
            return (
                `<div class='box'>
                    <div class='img-box'>
                        <img class='images' src=${image}></img>
                    </div> 
                    <div class='bottom'>
                        <p>${title}</p>
                        <h2>Php ${price}.00</h2>
                        <a href='${id}'><button>View Item</button></a>
                    </div>
                </div>`
            )
        }).join('')
    };
    displayItem(categories);

